package com.example.activityintentdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

@SuppressLint("NewApi")
public class MainActivity extends Activity
{
	public static final String DATA = "data";
	public static final String OBJECT = "object";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.second_layout_main);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	// send data to the other activity and display it
	// on the textview
	public void openSecondScreen(View view) {
		Intent intent = new Intent(MainActivity.this, SecondActivity.class);
		intent.putExtra(DATA, "I was started from the boss !");
		startActivity(intent);
	}
	
	public void askForData(View view) {
		Intent intent = new Intent(MainActivity.this, SecondActivity.class);
		startActivityForResult(intent, 100);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		// data is comming from the second activity
		if (requestCode == 100) {
			Toast.makeText(this,
			        data.getExtras().getString(SecondActivity.RETURN_DATA),
			        Toast.LENGTH_SHORT).show();
		}
	}
	
	public void sendObjectToAnotherScreen(View view) {
		Customer dimitar = new Customer("Dimitar", "Ivanov",
		        "somewhere on earth", 20);
		Intent intent = new Intent(MainActivity.this, SecondActivity.class);
		intent.putExtra(OBJECT, dimitar);
		startActivity(intent);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
