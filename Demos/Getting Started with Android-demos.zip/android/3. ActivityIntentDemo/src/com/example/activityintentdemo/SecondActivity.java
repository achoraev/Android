package com.example.activityintentdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends Activity
{
	public static final String RETURN_DATA = "return";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Bundle bundle = this.getIntent().getExtras();
		if (getIntent().hasExtra(MainActivity.DATA)) {
			TextView text = (TextView) findViewById(R.id.txtOne);
			text.setText(bundle.getString(MainActivity.DATA));
		} 

		if(getIntent().hasExtra(MainActivity.OBJECT)){
			Customer dimitar = bundle.getParcelable(MainActivity.OBJECT);
			TextView text = (TextView) findViewById(R.id.txtOne);
			text.setText(String.valueOf("Object age is :" + dimitar.Age));
		}											
	}

	@Override
    public void onBackPressed() {	    
	    Intent empty = new Intent();
	    empty.putExtra(RETURN_DATA, "Result was obtained");
	    setResult(100, empty);
	    finish();
    }
}
